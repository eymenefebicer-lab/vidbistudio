# VIDBI Studio

Tarayıcıda çalışan dikey video (YouTube Shorts) üretim stüdyosu. Konu seçer, Gemini ile senaryo ve seslendirme hazırlar, stok videolarla sahneleri kurar, videoyu tarayıcıda render eder ve istersen YouTube'a zamanlayarak yükler.

Sunucu yoktur. Tek dosyalık bir web uygulamasıdır (`index.html`).

## Anahtarlar depoda durmaz

Bu depoda hiçbir API anahtarı, token ya da kişisel bilgi yoktur. İlk açılışta bir kurulum sihirbazı çıkar ve bilgileri ister. Girdiğin her şey yalnızca o cihazın tarayıcı hafızasında (`localStorage`) saklanır.

## GitHub Pages ile yayınlama

1. Depoyu oluştur ve `index.html`, `README.md`, `.gitignore` dosyalarını yükle.
2. **Settings → Pages → Build and deployment** bölümünde kaynağı **Deploy from a branch** yap, dal olarak `main` ve klasör olarak `/ (root)` seç.
3. Birkaç dakika sonra sayfa `https://KULLANICI.github.io/DEPO/` adresinde açılır.
4. Sayfayı ilk açtığında kurulum sihirbazı başlar.

Dosyayı doğrudan çift tıklayıp yerelde de açabilirsin.

## Sihirbazın istediği bilgiler

| Adım | Bilgi | Zorunlu | Nereden alınır |
|---|---|---|---|
| Yapay zeka | Gemini API anahtarı (+ yedekler) | Evet | https://aistudio.google.com/apikey |
| Stok video | Pexels ve/veya Pixabay anahtarı | Önerilir | https://www.pexels.com/api/ · https://pixabay.com/api/docs/ |
| Kanallar | Kanal adı, konu alanı, dil, günlük video, yayın saatleri | Evet (en az 1 kanal) | Sen belirlersin |
| Kanallar | YouTube OAuth: Client ID, Client secret, Refresh token | Otomatik yükleme için | Google Cloud Console + OAuth Playground |
| Telegram | Bot anahtarı ve Chat ID | Hayır | https://t.me/BotFather |

YouTube izinleri: `youtube`, `youtube.upload`, `youtube.force-ssl`.
OAuth uygulaman "Test" modundaysa Google yenileme anahtarını 7 günde geçersiz kılar; "Üretimde" olarak yayınlarsan bu sınır olmaz.

Kurulumu sonradan değiştirmek için sağ üstteki **Kurulum** düğmesini kullan.

## Telegram komutları

`/baslat`, `/durdur`, `/durum`, `/ozet`, `/sonvideo`

## Güvenlik notları

- Anahtarlar tarayıcı hafızasında düz metin olarak durur. Ortak kullanılan bir bilgisayarda kurulum yapma.
- GitHub Pages'te `kullanici.github.io` altındaki tüm depolar aynı kaynağı (origin) paylaşır. Aynı hesapta güvenmediğin başka bir site yayınlıyorsan, o siteler bu hafızayı okuyabilir. Ayrı bir özel alan adı kullanmak bunu çözer.
- **Yedeği indir** dosyasına anahtarlar eklenmez; yine de `.gitignore` yedek dosyalarını depoya almaz.
- Anahtarlarından biri bir yere (sohbet, ekran görüntüsü, eski bir dosya) sızdıysa ilgili servisten iptal edip yenisini oluştur.

## İsteğe bağlı yerel render motoru

Uygulama `http://127.0.0.1:8787` adresinde çalışan ayrı bir yerel motor bulursa videoyu MP4/H.264'e dönüştürür. Bu motor bu depoda yoktur ve zorunlu değildir; motor yoksa video tarayıcının ürettiği biçimle devam eder.

## Sınırlar

- Otomasyon yalnızca sayfa açıkken çalışır; sekme kapanırsa durur.
- Video render sırasında sekmenin ekranda açık kalması gerekir.
- Otomatik üretim için kanalların YouTube bağlantısı gerekir. Elle video üretmek için gerekmez.
